
#> cinemalya:v1.0.5/intro/play
#
# @within	cinemalya:v1.0.5/intro/playsound with storage cinemalya:work intro
#
# @args		sound (unknown)
#

$execute at @e[tag=cinemalya.intro.title,limit=1] run playsound $(sound) ambient @a

