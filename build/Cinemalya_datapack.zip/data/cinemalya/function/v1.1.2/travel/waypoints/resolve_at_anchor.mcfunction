
#> cinemalya:v1.1.2/travel/waypoints/resolve_at_anchor
#
# @executed	as a throwaway marker freshly summoned on the caller's position
#
# @within	cinemalya:v1.1.2/travel/waypoints/resolve_at
#

function cinemalya:v1.1.2/travel/waypoints/face_ahead with storage cinemalya:work ahead
execute at @s run function cinemalya:v1.1.2/travel/waypoints/resolve_at_run with storage cinemalya:work one_at
kill @s

