
#> cinemalya:v1.1.2/playback/spawn_particle
#
# @executed	at @s
#
# @within	cinemalya:v1.1.2/playback/particle with storage cinemalya:work trail [ at @s ]
#
# @args		particle (unknown)
#

$particle $(particle) ~ ~ ~ 0.2 0.2 0.2 0 2

