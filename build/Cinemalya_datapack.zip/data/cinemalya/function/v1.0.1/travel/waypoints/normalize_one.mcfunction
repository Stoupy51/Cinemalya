
#> cinemalya:v1.0.1/travel/waypoints/normalize_one
#
# @within	cinemalya:v1.0.1/travel/waypoints/normalize_loop
#

execute store result storage cinemalya:work sel.i int 1 run scoreboard players get #w cinemalya.data
function cinemalya:v1.0.1/travel/waypoints/fill with storage cinemalya:work sel
scoreboard players add #w cinemalya.data 1
function cinemalya:v1.0.1/travel/waypoints/normalize_loop

