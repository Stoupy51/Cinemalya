
#> cinemalya:v1.1.0/editor/label_text
#
# @executed	anchored eyes & positioned ^ ^ ^
#
# @within	cinemalya:v1.1.0/editor/label with storage cinemalya:editor label
#
# @args		n (unknown)
#

$data modify entity @s text set value {text:"$(n)",color:"gold",bold:true}

