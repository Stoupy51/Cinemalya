
#> cinemalya:v1.1.0/api/signals/on_launch
#
# @within	#cinemalya:v1/signals/on_launch
#
# @description		Placeholder so the tag always resolves. Add your own function to the tag to react to the event.
#


