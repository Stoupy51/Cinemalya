# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

scoreboard objectives add bs.ctx dummy [{text:"BS ",color:"dark_gray"},{text:"Context",color:"aqua"}]
scoreboard objectives add bs.const dummy [{text:"BS ",color:"dark_gray"},{text:"Constants",color:"aqua"}]

scoreboard players set -1000 bs.const -1000
scoreboard players set -18 bs.const -18
scoreboard players set -2 bs.const -2
scoreboard players set 2 bs.const 2
scoreboard players set 3 bs.const 3
scoreboard players set 4 bs.const 4
scoreboard players set 6 bs.const 6
scoreboard players set 1000 bs.const 1000

data modify storage bs:const spline.pad set value [[],[]]
