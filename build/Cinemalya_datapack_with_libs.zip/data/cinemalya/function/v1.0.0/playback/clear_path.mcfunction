
#> cinemalya:v1.0.0/playback/clear_path
#
# @executed	at @s
#
# @within	cinemalya:v1.0.0/playback/kill with storage cinemalya:work sel
#
# @args		i (unknown)
#

$data remove storage cinemalya:work paths.i$(i)

