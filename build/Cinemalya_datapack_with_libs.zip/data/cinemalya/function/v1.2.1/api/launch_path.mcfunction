
#> cinemalya:v1.2.1/api/launch_path
#
# @within	#cinemalya:v1/launch_path
#
# @args		with (unknown)
#
# @description		Version guard: only the newest cinemalya loaded in the world runs the call.
# 				The loaded check matters just as much. The version scores are set the moment the pack
# 				is read, while the constants every computation divides by are written by confirm_load,
# 				which waits for a player to be online. A call landing in that window would compute its
# 				sampling step from zeroed constants and hang the server inside the spline sampler.
#

$execute if score #cinemalya.loaded load.status matches 1 if score #cinemalya.major load.status matches 1 if score #cinemalya.minor load.status matches 2 if score #cinemalya.patch load.status matches 1 run function cinemalya:v1.2.1/travel/from_waypoints {with:$(with)}

