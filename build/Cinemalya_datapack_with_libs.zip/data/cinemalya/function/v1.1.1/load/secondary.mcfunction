
#> cinemalya:v1.1.1/load/secondary
#
# @within	cinemalya:v1.1.1/load/main
#

# Cinemalya
scoreboard objectives add cinemalya.data dummy
tag Stoupy51 add convention.debug

# Check dependencies and wait for a player to connect (to get server version)
function cinemalya:v1.1.1/load/check_dependencies
function cinemalya:v1.1.1/load/valid_dependencies

