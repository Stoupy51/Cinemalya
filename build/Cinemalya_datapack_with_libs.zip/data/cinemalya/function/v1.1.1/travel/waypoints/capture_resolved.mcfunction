
#> cinemalya:v1.1.1/travel/waypoints/capture_resolved
#
# @executed	at @s
#
# @within	cinemalya:v1.1.1/travel/waypoints/resolve_at_run
#

data modify storage cinemalya:work resolved set from entity @s Pos
kill @s

