
#> cinemalya:v1.1.1/travel/tags/loop
#
# @within	cinemalya:v1.1.1/travel/tags/main
#			cinemalya:v1.1.1/travel/tags/one
#

execute if score #t cinemalya.data < #tag_count cinemalya.data run function cinemalya:v1.1.1/travel/tags/one

