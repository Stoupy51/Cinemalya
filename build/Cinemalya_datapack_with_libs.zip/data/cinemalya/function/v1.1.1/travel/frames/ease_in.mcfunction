
#> cinemalya:v1.1.1/travel/frames/ease_in
#
# @within	cinemalya:v1.1.1/travel/frames/ease
#

# p squared: slow to start, fastest on arrival
scoreboard players operation #p cinemalya.data *= #p cinemalya.data
scoreboard players operation #p cinemalya.data /= #10000 cinemalya.data

